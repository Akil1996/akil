from django.apps import AppConfig


class PersontopersonConfig(AppConfig):
    name = 'persontoperson'
